#include "uart.h"

#define PERIPH_BASE 0x40000000UL
#define APB2PERIPH_BASE (PERIPH_BASE + 0x00010000UL)
#define AHBPERIPH_BASE (PERIPH_BASE + 0x00020000UL)

#define GPIOA_BASE (APB2PERIPH_BASE + 0x00000800UL)
#define RCC_BASE (AHBPERIPH_BASE + 0x00001000UL)
#define USART1_BASE (APB2PERIPH_BASE + 0x00003800UL)

#define REG32(addr) (*(volatile uint32_t *)(addr))

#define RCC_APB2ENR REG32(RCC_BASE + 0x18UL)

#define GPIOA_CRH REG32(GPIOA_BASE + 0x04UL)

#define USART1_SR REG32(USART1_BASE + 0x00UL)
#define USART1_DR REG32(USART1_BASE + 0x04UL)
#define USART1_BRR REG32(USART1_BASE + 0x08UL)
#define USART1_CR1 REG32(USART1_BASE + 0x0CUL)

#define NVIC_ISER0 REG32(0xE000E100UL)
#define NVIC_ISER1 REG32(0xE000E104UL)

#define RCC_APB2ENR_IOPAEN (1UL << 2)
#define RCC_APB2ENR_USART1EN (1UL << 14)

#define USART_SR_RXNE (1UL << 5)
#define USART_SR_TXE (1UL << 7)

#define USART_CR1_RXNEIE (1UL << 5)
#define USART_CR1_RE (1UL << 2)
#define USART_CR1_TE (1UL << 3)
#define USART_CR1_UE (1UL << 13)

#define USART1_IRQN (37UL)
#define UART1_RX_FRAME_LEN 6U

static volatile char rx_frame[UART1_RX_FRAME_LEN];
static volatile uint32_t rx_index;
static volatile uint32_t rx_frame_ready;

static void uart1_enable_rx_interrupt(void)
{
  NVIC_ISER1 = (1UL << (USART1_IRQN - 32UL));
  USART1_CR1 |= USART_CR1_RXNEIE;
}

void uart1_init(void)
{
  RCC_APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_USART1EN;

  /*
   * PA9  = USART1_TX: alternate-function push-pull, 50 MHz.
   * PA10 = USART1_RX: floating input.
   */
  GPIOA_CRH &= ~((0xFUL << 4) | (0xFUL << 8));
  GPIOA_CRH |= (0xBUL << 4) | (0x4UL << 8);

  /* PCLK2 defaults to 8 MHz from HSI. 8 MHz / 9600 = BRR 0x0341. */
  USART1_BRR = 0x0341UL;
  USART1_CR1 = USART_CR1_UE | USART_CR1_TE | USART_CR1_RE;
  uart1_enable_rx_interrupt();
}

void uart1_write_char(char ch)
{
  while ((USART1_SR & USART_SR_TXE) == 0U) {
  }

  USART1_DR = (uint32_t)(uint8_t)ch;
}

void uart1_write_string(const char *text)
{
  while (*text != '\0') {
    uart1_write_char(*text);
    text++;
  }
}

void uart1_handle_rx_irq(void)
{
  const uint32_t sr = USART1_SR;

  if ((sr & USART_SR_RXNE) == 0U) {
    return;
  }

  const char ch = (char)(USART1_DR & 0xFFU);

  if (rx_frame_ready != 0U) {
    return;
  }

  rx_frame[rx_index] = ch;
  rx_index++;

  if (rx_index >= UART1_RX_FRAME_LEN) {
    rx_frame_ready = 1U;
    rx_index = 0U;
  }
}

int uart1_take_rx_frame(char *out, uint32_t len)
{
  uint32_t i;

  if (len < UART1_RX_FRAME_LEN) {
    return 0;
  }

  if (rx_frame_ready == 0U) {
    return 0;
  }

  for (i = 0U; i < UART1_RX_FRAME_LEN; i++) {
    out[i] = rx_frame[i];
  }

  rx_frame_ready = 0U;
  return 1;
}

void USART1_IRQHandler(void)
{
  uart1_handle_rx_irq();
}

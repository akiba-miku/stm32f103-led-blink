#include "uart.h"

#define PERIPH_BASE 0x40000000UL
#define APB2PERIPH_BASE (PERIPH_BASE + 0x00010000UL)
#define AHBPERIPH_BASE (PERIPH_BASE + 0x00020000UL)

#define GPIOA_BASE (APB2PERIPH_BASE + 0x00000800UL)
#define RCC_BASE (AHBPERIPH_BASE + 0x00001000UL)
#define USART1_BASE (APB2PERIPH_BASE + 0x00003800UL)
#define DMA1_BASE (AHBPERIPH_BASE + 0x00000000UL)

#define REG32(addr) (*(volatile uint32_t *)(addr))

#define RCC_APB2ENR REG32(RCC_BASE + 0x18UL)
#define RCC_AHBENR REG32(RCC_BASE + 0x14UL)

#define GPIOA_CRH REG32(GPIOA_BASE + 0x04UL)

#define USART1_SR REG32(USART1_BASE + 0x00UL)
#define USART1_DR REG32(USART1_BASE + 0x04UL)
#define USART1_BRR REG32(USART1_BASE + 0x08UL)
#define USART1_CR1 REG32(USART1_BASE + 0x0CUL)
#define USART1_CR3 REG32(USART1_BASE + 0x14UL)

#define DMA1_ISR REG32(DMA1_BASE + 0x00UL)
#define DMA1_IFCR REG32(DMA1_BASE + 0x04UL)

#define DMA1_CH5_CCR REG32(DMA1_BASE + 0x58UL)
#define DMA1_CH5_CNDTR REG32(DMA1_BASE + 0x5CUL)
#define DMA1_CH5_CPAR REG32(DMA1_BASE + 0x60UL)
#define DMA1_CH5_CMAR REG32(DMA1_BASE + 0x64UL)

#define NVIC_ISER0 REG32(0xE000E100UL)
#define NVIC_ISER1 REG32(0xE000E104UL)

#define RCC_APB2ENR_IOPAEN (1UL << 2)
#define RCC_APB2ENR_USART1EN (1UL << 14)
#define RCC_AHBENR_DMA1EN (1UL << 0)

#define USART_SR_TXE (1UL << 7)

#define USART_CR1_RE (1UL << 2)
#define USART_CR1_TE (1UL << 3)
#define USART_CR1_UE (1UL << 13)

#define USART_CR3_DMAR (1UL << 6)

#define DMA_CCR_EN (1UL << 0)
#define DMA_CCR_TCIE (1UL << 1)
#define DMA_CCR_DIR (1UL << 4)
#define DMA_CCR_CIRC (1UL << 5)
#define DMA_CCR_PINC (1UL << 6)
#define DMA_CCR_MINC (1UL << 7)
#define DMA_CCR_PL_HIGH (1UL << 12)

#define USART1_IRQN (37UL)
#define DMA1_CHANNEL5_IRQN (15UL)

#define UART1_RX_FRAME_LEN 10U

#define DMA1_IFCR_CGIF5 (1UL << 16)
#define DMA1_IFCR_CTCIF5 (1UL << 17)
#define DMA1_IFCR_CHTIF5 (1UL << 18)
#define DMA1_IFCR_CTEIF5 (1UL << 19)

static volatile uint8_t rx_dma_buffer[UART1_RX_FRAME_LEN];
static volatile uint8_t rx_frame[UART1_RX_FRAME_LEN];
static volatile uint32_t rx_frame_ready;

static void uart1_disable_irq(void)
{
  __asm volatile("cpsid i" ::: "memory");
}

static void uart1_enable_irq(void)
{
  __asm volatile("cpsie i" ::: "memory");
}

static void uart1_enable_nvic(void)
{
  NVIC_ISER0 = (1UL << DMA1_CHANNEL5_IRQN);
  NVIC_ISER1 = (1UL << (USART1_IRQN - 32UL));
}

static void uart1_rearm_dma_rx(void)
{
  DMA1_CH5_CCR &= ~DMA_CCR_EN;
  DMA1_IFCR = DMA1_IFCR_CGIF5 | DMA1_IFCR_CTCIF5 | DMA1_IFCR_CHTIF5 | DMA1_IFCR_CTEIF5;
  DMA1_CH5_CMAR = (uint32_t)(uintptr_t)rx_dma_buffer;
  DMA1_CH5_CNDTR = UART1_RX_FRAME_LEN;
  DMA1_CH5_CCR |= DMA_CCR_EN;
}

void uart1_init(void)
{
  RCC_APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_USART1EN;
  RCC_AHBENR |= RCC_AHBENR_DMA1EN;

  /*
   * PA9  = USART1_TX: alternate-function push-pull, 50 MHz.
   * PA10 = USART1_RX: floating input.
   */
  GPIOA_CRH &= ~((0xFUL << 4) | (0xFUL << 8));
  GPIOA_CRH |= (0xBUL << 4) | (0x4UL << 8);

  /* PCLK2 defaults to 8 MHz from HSI. 8 MHz / 9600 = BRR 0x0341. */
  USART1_BRR = 0x0341UL;
  USART1_CR1 = USART_CR1_UE | USART_CR1_TE | USART_CR1_RE;

  DMA1_CH5_CCR &= ~DMA_CCR_EN;
  DMA1_CH5_CPAR = (uint32_t)(uintptr_t)&USART1_DR;
  DMA1_CH5_CMAR = (uint32_t)(uintptr_t)rx_dma_buffer;
  DMA1_CH5_CNDTR = UART1_RX_FRAME_LEN;
  DMA1_CH5_CCR = DMA_CCR_MINC | DMA_CCR_TCIE | DMA_CCR_PL_HIGH;

  USART1_CR3 |= USART_CR3_DMAR;
  uart1_enable_nvic();
  uart1_rearm_dma_rx();
}

void uart1_write_char(char ch)
{
  while ((USART1_SR & USART_SR_TXE) == 0U) {
  }

  USART1_DR = (uint32_t)(uint8_t)ch;
}

void uart1_write_string(const char *text)
{
  while (*text != '\0') {
    uart1_write_char(*text);
    text++;
  }
}

int uart1_take_rx_frame(char *out, uint32_t len)
{
  uint32_t i;

  if (len < UART1_RX_FRAME_LEN) {
    return 0;
  }

  uart1_disable_irq();

  if (rx_frame_ready == 0U) {
    uart1_enable_irq();
    return 0;
  }

  for (i = 0U; i < UART1_RX_FRAME_LEN; i++) {
    out[i] = (char)rx_frame[i];
  }

  rx_frame_ready = 0U;
  uart1_rearm_dma_rx();
  uart1_enable_irq();
  return 1;
}

void DMA1_Channel5_IRQHandler(void)
{
  uint32_t i;

  if ((DMA1_ISR & (1UL << 17)) == 0U) {
    return;
  }

  for (i = 0U; i < UART1_RX_FRAME_LEN; i++) {
    rx_frame[i] = rx_dma_buffer[i];
  }

  rx_frame_ready = 1U;
  DMA1_IFCR = DMA1_IFCR_CGIF5 | DMA1_IFCR_CTCIF5 | DMA1_IFCR_CHTIF5 | DMA1_IFCR_CTEIF5;
  DMA1_CH5_CCR &= ~DMA_CCR_EN;
}

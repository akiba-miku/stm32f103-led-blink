# 实验二：USART 串口 DMA 接收与回显

## 实验目标

- 使用 USART1 DMA 接收串口数据。
- 每次接收 10 个字符后，将这 10 个字符原样回显到串口。
- 板载 LED 继续闪烁，用于确认程序在运行。

## 硬件连接

| STM32F103C8T6 | 串口模块 |
| --- | --- |
| PA9 / USART1_TX | RX |
| PA10 / USART1_RX | TX |
| GND | GND |

串口参数：`9600 8N1`。

## 代码结构

| 文件 | 作用 |
| --- | --- |
| `Core/Inc/uart.h` | USART1 接口声明 |
| `Core/Src/uart.c` | USART1 初始化、发送、DMA 接收 |
| `Core/Src/main.c` | 实验主流程 |

## 运行现象

串口终端每发送 10 个字符，单片机会原样回显这 10 个字符：

```text
ABCDEFGHIJ
```

同时板载 PC13 LED 继续以 500 ms 周期翻转，用于确认程序正在运行。
